const data = [
    { id: 1, title: "Feature 1", description: "This is feature 1 details." },
    { id: 2, title: "Feature 2", description: "This is feature 2 details." },
    { id: 3, title: "Feature 3", description: "This is feature 3 details." },
    { id: 4, title: "Feature 4", description: "This is feature 4 details." },
  ];
  
  export default data;
      